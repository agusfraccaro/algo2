En el zip se encuentran:
-las carpetas de cada tda, con su .h y .c
-El juego.c
-el enunciado
-la biblioteca de la venganza de arya (.c y .h)
-el victimas.txt y el ciudades.dat proporcionados por la catedra en el cual se basan los casos de pruebas que hay en este readme

Cada vez que se ingresa una opcion, deberas presionar cualquier letra para acceder nuevamente al menu de opciones. 

Para jugar al juego, se espera que el usuario no mate dos veces a la persona en la misma ciudad (o sea que no ingrese dos veces la opcion I, o si la ingresa una segunda vez que decida NO (N) matar), ya que se le informa por pantalla que enfrente tiene el cadaver de esa persona. Si el beneficio de la persona que mata al usuario es matar a la proxima victima en tu lista, entonces vos no vas a pasar por esa ciudad donde estaba esa victima (se elimina la ciudad). Cada vez que se avanza de ciudad, la ciudad en la que estabas se elimina de la lista.

Para perder: se puede o matar a la primera persona y luego ingresar mal una letra 5 veces, o bien no matar a la primera persona ni a Ser Meryn Trant, no matar a El Duki y luego matar a The Waif. 
Tambien podes matar a todos los que esten en tu lista, pero no matar a Lord Mendez (tiene la llave) entonces no vas a poder matar a Walder Frey y por lo tanto perdes.

Para ganar: matar a todos los de tu lista y ademas a Lord Mendez (tiene la llave), evitar matar a Manuel Camejo, Lord Gonzalo Martinez Sastre y a P. Sherman (te restan mucha vida). Si queres ahorrarte matar a uno, podes matar a El Duki que tiene el beneficio de asesinar al siguiente de tu lista de victimas. En el caso de que pierdas vida, podes matar a Lady Mirtha Legrand, Lady Lyessa Flint o a Agustin Teston.

Línea de compilacion: gcc *.c -g -Wall -Wconversion -Werror -std=c99 -o la_venganza_de_arya

Línea de ejecucion: valgrind --leak-check=full --track-origins=yes --show-reachable=yes ./la_venganza_de_arya 

